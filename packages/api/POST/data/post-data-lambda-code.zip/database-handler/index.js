"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getData = exports.uploadData = void 0;
var upload_data_1 = require("./upload-data");
Object.defineProperty(exports, "uploadData", { enumerable: true, get: function () { return upload_data_1.uploadData; } });
var get_data_1 = require("./get-data");
Object.defineProperty(exports, "getData", { enumerable: true, get: function () { return get_data_1.getData; } });
