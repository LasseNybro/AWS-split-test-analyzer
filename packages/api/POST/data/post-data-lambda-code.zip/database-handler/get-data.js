"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getData = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const config_1 = __importDefault(require("../config"));
const getData = async (client, customerId, userId_ExperimentalId) => {
    console.log("Fetching data entry from DynamoDB:", customerId, userId_ExperimentalId);
    const params = {
        TableName: config_1.default.dynamoDbTableName,
        Key: {
            customerId: { S: customerId },
            userId_ExperimentalId: { S: userId_ExperimentalId },
        },
    };
    try {
        const command = new client_dynamodb_1.GetItemCommand(params);
        const existingDataEntry = await client.send(command);
        console.log("Data entry fetched successfully");
        return existingDataEntry.Item ? (0, util_dynamodb_1.unmarshall)(existingDataEntry.Item) : undefined;
    }
    catch (error) {
        console.error("Error uploading data entry:", error);
        throw error; // Rethrow error to handle it in the calling function
    }
};
exports.getData = getData;
