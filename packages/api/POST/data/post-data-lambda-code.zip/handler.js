"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const event_handler_1 = require("./event-handler");
const config_1 = __importDefault(require("./config"));
const handler = async (event) => {
    console.log(`Received ${event.Records.length} messages from SQS`);
    for (const record of event.Records) {
        await processMessage(record);
    }
    return;
};
exports.handler = handler;
const processMessage = async (record) => {
    console.log('Processing message:', record.messageId);
    console.log('Message Body:', record.body);
    const client = new client_dynamodb_1.DynamoDBClient({
        region: config_1.default.awsRegion
    });
    // Example: parse JSON body if your messages are JSON
    try {
        await (0, event_handler_1.postData)(client, record.body);
        // Do something with the data here (e.g., store in DB, call API, etc.)
    }
    catch (error) {
        console.error(`Error processing message ${record.messageId}:`, error);
        throw error; // Rethrow error to ensure message is not deleted from SQS
    }
};
