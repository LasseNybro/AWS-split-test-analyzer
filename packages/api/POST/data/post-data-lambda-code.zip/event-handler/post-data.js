"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.postData = void 0;
const database_handler_1 = require("../database-handler");
const config_1 = __importDefault(require("../config"));
const postData = async (client, body) => {
    const incomingData = JSON.parse(body);
    if (incomingData.length > config_1.default.upperLimitOnEvents) {
        throw new Error(`Too many events received: ${incomingData.length}. Maximum allowed is ${config_1.default.upperLimitOnEvents}.`);
    }
    ;
    const dataEntries = await Promise.all(incomingData.map(async (data) => {
        const dataEntry = await createDataEntry(client, data);
        await (0, database_handler_1.uploadData)(client, dataEntry);
    }));
};
exports.postData = postData;
const createDataEntry = async (client, data) => {
    // Implement your logic to create a data entry
    // This is a placeholder function; replace with actual implementation
    const userId_ExperimentalId = `${data.userId}_${data.experimentId}`;
    const customerId = data.customerId;
    const existingDataEntry = await (0, database_handler_1.getData)(client, customerId, userId_ExperimentalId);
    const createdAt = existingDataEntry ? new Date(existingDataEntry.createdAt) : new Date();
    console.log('Parsed message body:', data);
    console.log('Creating data entry with data:', data);
    return {
        customerId,
        userId_ExperimentalId,
        createdAt,
        userId: data.userId,
        experimentId: data.experimentId,
        variant: data.variant,
        value: data.value,
        lastChanged: new Date(),
    };
};
