"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postData = void 0;
var post_data_1 = require("./post-data");
Object.defineProperty(exports, "postData", { enumerable: true, get: function () { return post_data_1.postData; } });
